package com.example.flutter_music_app


import com.ryanheise.audioservice.AudioServiceActivity

class MainActivity: AudioServiceActivity() {
    // Không cần thêm gì khác, FlutterActivity sẽ tự động handle
}