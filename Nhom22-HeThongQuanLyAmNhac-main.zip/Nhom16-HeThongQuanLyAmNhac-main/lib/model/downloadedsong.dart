// import 'package:hive/hive.dart';



// @HiveType(typeId: 0)
// class DownloadedSong extends HiveObject {
//   @HiveField(0)
//   int songId;

//   @HiveField(1)
//   String songName;

//   @HiveField(2)
//   String artistName;

//   @HiveField(3)
//   String localPath;

//   @HiveField(4)
//   String imagePath;

//   @HiveField(5)
//   DateTime downloadDate;

//   @HiveField(6)
//   int fileSize;

//   @HiveField(7)
//   String? lrcPath;

//   DownloadedSong({
//     required this.songId,
//     required this.songName,
//     required this.artistName,
//     required this.localPath,
//     required this.imagePath,
//     required this.downloadDate,
//     required this.fileSize,
//     this.lrcPath,
//   });
// }
